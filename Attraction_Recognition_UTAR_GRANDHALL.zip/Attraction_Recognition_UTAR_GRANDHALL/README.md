# Remember to enable your API keys on Google Cloud Platform

# And insert your API keys at translate_page.dart and android manifest

# At android manifest, add the api key to android:value
# <meta-data android:name="com.google.android.geo.API_KEY" android:value=[API_KEY}/>